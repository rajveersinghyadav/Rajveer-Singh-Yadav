# RJAnalyser AI — Self-Learning Trading Analysis App

> A real-time AI-powered trading analysis web app built with React + TypeScript + Vite.
> Pulls live market data from Binance, runs a full AI analysis engine, and **self-learns market patterns** — storing what it sees and showing you mini candlestick charts of every pattern it recognised.

---

## 📱 Screenshots

| Chart + AI Panel | AI Chat — Pattern Memory |
|---|---|
| Live TradingView chart with AI signal overlay | Ask "what did you learn?" and see mini charts |

---

## ✨ Features

- **Live Binance Data** — Real-time WebSocket candle feed for all crypto pairs (BTCUSDT, ETHUSDT, etc.) — no API key required
- **Full AI Engine** — Trend, momentum, buyer/seller pressure, volatility, candlestick pattern recognition, market structure (BOS / CHoCH)
- **Buy / Sell / Wait Signals** with confidence scoring, Stop Loss, TP1 / TP2 / TP3, and Risk:Reward ratio
- **Self-Learning Memory** — Every high-confidence signal is saved to `localStorage` as a learned pattern with its 20-candle snapshot
- **Pattern Visualiser** — Ask the AI "show bullish patterns" or "show bearish patterns" and see mini SVG candlestick charts for every pattern it learned
- **AI Chat** — Natural-language interface to query signals, trends, targets, and the pattern memory
- **Trade History** — Auto-logged trades stored in `localStorage`, outcome (WIN/LOSS) written back after simulated 5-minute close
- **Dark Terminal Aesthetic** — JetBrains Mono / Inter, `#0a0e1a` background, green pulse animations
- **TradingView Widget** — Embedded professional charting for any symbol
- **Multi-Asset** — Crypto, Forex (XAUUSD, EURUSD …), Indices (NAS100 …), Commodities

---

## 📁 Project Structure

```
rjanalyser/
├── index.html                      ← Entry HTML (Google Fonts linked here)
├── package.json
├── vite.config.ts
├── tsconfig.json
├── components.json                 ← shadcn/ui config
│
└── src/
    ├── main.tsx                    ← React root mount
    ├── App.tsx                     ← Router + AppProvider wrapper
    ├── index.css                   ← Dark terminal theme + CSS variables
    │
    ├── lib/
    │   ├── state.tsx               ← Global app state (Context + useReducer)
    │   ├── assets.ts               ← Asset lists + TradingView symbol map
    │   ├── binance.ts              ← Binance REST fetchCandles + WebSocket hook
    │   ├── tradingview.ts          ← TradingView widget dynamic loader hook
    │   ├── utils.ts                ← Formatting helpers
    │   └── ai/
    │       ├── engine.ts           ← Full AI analysis engine (pure functions)
    │       └── patternMemory.ts    ← Self-learning pattern storage engine
    │
    ├── hooks/
    │   ├── useAnalysis.ts          ← Orchestration: candles → AI → state + memory
    │   ├── use-mobile.tsx
    │   └── use-toast.ts
    │
    ├── components/
    │   ├── TopBar.tsx              ← App header with connection status
    │   ├── BottomNav.tsx           ← 5-tab bottom navigation
    │   ├── PatternCard.tsx         ← Mini SVG candlestick chart for learned patterns
    │   └── ui/                     ← shadcn/ui component library (50+ components)
    │
    └── pages/
        ├── ChartPage.tsx           ← Main chart + AI analysis panel
        ├── QuotesPage.tsx          ← Searchable asset watchlist
        ├── AiChatPage.tsx          ← AI chat with self-learning pattern display
        ├── HistoryPage.tsx         ← Trade history from localStorage
        ├── SettingsPage.tsx        ← App settings
        └── not-found.tsx
```

---

## 🚀 Installation — Step by Step

### Prerequisites

| Tool | Version | Install |
|---|---|---|
| Node.js | 18 or above | https://nodejs.org |
| pnpm | 8 or above | `npm install -g pnpm` |
| Git | Any | https://git-scm.com |

---

### Step 1 — Clone or Upload to GitHub

**Option A — Upload from ZIP:**
1. Create a new repository on GitHub (e.g. `rjanalyser`)
2. Unzip the downloaded file
3. Open each `.txt` file, copy the code, create the matching file in your GitHub repo at the same path, paste, and save
4. Make sure the folder structure matches exactly as shown above

**Option B — Clone and push:**
```bash
git init rjanalyser
cd rjanalyser
# paste all your files into the correct folders
git add .
git commit -m "Initial commit: RJAnalyser AI"
git remote add origin https://github.com/YOUR_USERNAME/rjanalyser.git
git push -u origin main
```

---

### Step 2 — Install Dependencies

```bash
# Navigate into the project folder
cd rjanalyser

# Install all packages
pnpm install
```

If you do not have pnpm:
```bash
npm install -g pnpm
pnpm install
```

---

### Step 3 — Run the Development Server

```bash
pnpm dev
```

The app will open at **http://localhost:5173**

---

### Step 4 — Build for Production

```bash
pnpm build
```

Output goes to `dist/`. Deploy this folder to any static host (Vercel, Netlify, GitHub Pages, etc.).

---

### Step 5 — Deploy to Vercel (Recommended)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel

# Follow the prompts — choose the rjanalyser folder as root
```

Or connect your GitHub repo to https://vercel.com and it will auto-deploy on every push.

---

## 🧠 How the Self-Learning AI Works

### Pattern Detection
Every time the AI engine fires a **BUY or SELL signal with ≥65% confidence**, it:
1. Takes a snapshot of the last 20 candles
2. Records the pattern name, trend, buyer/seller pressure, confidence, entry price, stop loss, and targets
3. Saves it to `localStorage` under the key `rjanalyser_learned_patterns`

### Pattern Outcome Tracking
After 5 minutes (simulated trade close), the outcome (WIN or LOSS) is written back into the saved pattern. This lets the AI report its win rate over time.

### Asking the AI What It Learned
Open the **AI** tab and ask:

| Query | What you get |
|---|---|
| `what did you learn?` | Summary: total patterns, win/loss count, most common patterns |
| `show bullish patterns` | Horizontal scroll of mini candlestick charts for all UP patterns |
| `show bearish patterns` | Horizontal scroll of mini candlestick charts for all DOWN patterns |
| `show all patterns` | All stored patterns |
| `how many patterns?` | Count by direction |
| `clear memory` | Wipes all stored patterns |

### Mini Chart Cards
Each pattern card shows:
- **Direction label** (▲ BULLISH / ▼ BEARISH) with colour coding
- **Mini SVG candlestick chart** of the 20-candle snapshot at the time of detection
- Pattern name, confidence %, timeframe, buyer/seller ratio
- Outcome badge (✅ WIN / ❌ LOSS / ⏳ PENDING)

---

## 📡 Data Sources

| Asset Class | Data Source | Notes |
|---|---|---|
| Crypto (BTC, ETH, BNB …) | Binance WebSocket + REST API | Real-time, no API key needed |
| Forex (XAUUSD, EURUSD …) | Simulated random walk seeded from real crypto volatility | For visual demo |
| Indices (NAS100, SPX …) | Simulated | For visual demo |
| Commodities | Simulated | For visual demo |

> To add real Forex data, replace the `simulateLiveCandles` function in `src/lib/binance.ts` with a call to a free Forex WebSocket provider (e.g. Polygon.io or OANDA stream).

---

## ⚙️ Configuration

All user-facing settings are in the **Settings** tab of the app and stored in `localStorage`:

| Setting | Default | Description |
|---|---|---|
| Lot Size | 0.01 | Simulated trade lot size |
| AI Sensitivity | 65% | Minimum confidence to fire a signal |
| Refresh Interval | 5s | How often the analysis re-runs |
| Sound Alerts | Off | Beep on signal |
| Auto Trade | Off | Auto-log trades on signal |

---

## 🔧 Key Files Explained

### `src/lib/ai/engine.ts`
Pure functions — no side effects, fully testable.
- `getTrend(candles)` — counts bullish vs bearish candles over last 20
- `getBuyerSeller(candles)` — measures wick vs body pressure
- `getMomentum(candles)` — compares last-5 avg close vs prev-5 avg close
- `getVolatility(candles)` — ATR / avg close ratio
- `getConfidence(...)` — weighted score from all four factors
- `getPattern(candles)` — Doji, Hammer, Shooting Star, Engulfing detection
- `getMarketStructure(candles, trend)` — BOS BULL / BOS BEAR / CHoCH detection
- `runAnalysis(candles)` — runs all functions, produces full `AIAnalysis` object

### `src/lib/ai/patternMemory.ts`
Self-learning engine.
- `learnPattern(asset, timeframe, candles, analysis)` — saves a pattern snapshot
- `getAllPatterns()` — returns all stored patterns newest first
- `getPatternsByDirection('UP' | 'DOWN')` — filters by direction
- `getLearningReport()` — generates a human-readable summary string
- `updatePatternOutcome(id, outcome, pnlPercent)` — writes WIN/LOSS back
- `clearMemory()` — wipes localStorage

### `src/lib/binance.ts`
- `fetchCandles(symbol, interval, limit)` — REST call to `api.binance.com/api/v3/klines`
- `useLiveCandles(asset, timeframe)` — React hook that opens a WebSocket to `stream.binance.com` for crypto, or runs a simulated walk for non-crypto assets

### `src/hooks/useAnalysis.ts`
The orchestration layer that connects everything:
1. Calls `useLiveCandles` to get fresh candles
2. Calls `runAnalysis` via `useMemo`
3. Dispatches results to global state
4. On high-confidence signal: calls `learnPattern` + dispatches a trade to history

---

## 🛠 Troubleshooting

| Problem | Fix |
|---|---|
| Blank screen on start | Run `pnpm install` then `pnpm dev` |
| `Cannot find module` error | Make sure the folder structure matches exactly — file names are case-sensitive |
| Binance CORS error in browser | Use the app on `localhost` during development; for production deploy to HTTPS |
| Patterns not saving | Check browser `localStorage` is not blocked (private mode) |
| TradingView chart not loading | Check internet connection — it loads from `cdn.tradingview.com` |
| pnpm not found | Run `npm install -g pnpm` first |

---

## 📦 Dependencies

```json
{
  "react": "^18",
  "typescript": "^5",
  "vite": "^5",
  "wouter": "routing",
  "lucide-react": "icons",
  "tailwindcss": "styling",
  "class-variance-authority": "component variants",
  "@radix-ui/*": "headless UI primitives"
}
```

No backend required. No API keys required for crypto data.

---

## 🗺 Roadmap / Future Improvements

- [ ] Real Forex/Indices live data via Polygon.io or Yahoo Finance
- [ ] Pattern win-rate statistics page
- [ ] Pattern export to CSV
- [ ] Push notifications on signal fire
- [ ] Multi-timeframe confluence analysis
- [ ] Pattern image export (save chart as PNG)
- [ ] Cloud sync of learned patterns (Supabase / Firebase)

---

## 📄 License

MIT — free to use, modify, and distribute.

---

*Built with React + TypeScript + Vite | Powered by Binance Public API | TradingView Charting Library*
